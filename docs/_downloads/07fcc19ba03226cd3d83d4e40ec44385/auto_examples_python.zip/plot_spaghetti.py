"""
Example spaghetti plot
"""